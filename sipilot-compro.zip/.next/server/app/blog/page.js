(() => {
var exports = {};
exports.id = 404;
exports.ids = [404];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 53918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 64486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 99552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 78524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 47342:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/no-ssr-error.js");

/***/ }),

/***/ 64406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 46220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 10299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 35789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 34567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 68424:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(72315);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62333);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(62885);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(19505);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(90683);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(23269);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(85746);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8208);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7__);

    const tree = {
        children: [
        '',
        {
        children: [
        'blog',
        {
        children: ['', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 30234)), "E:\\KERJAAN\\MaestroSupremeTech\\Projects\\website\\sipilot\\sipilot-compro\\app\\blog\\page.tsx"]}]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 33531)), "E:\\KERJAAN\\MaestroSupremeTech\\Projects\\website\\sipilot\\sipilot-compro\\app\\blog\\layout.tsx"],
'head': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 60380)), "E:\\KERJAAN\\MaestroSupremeTech\\Projects\\website\\sipilot\\sipilot-compro\\app\\blog\\head.tsx"],
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 48514)), "E:\\KERJAAN\\MaestroSupremeTech\\Projects\\website\\sipilot\\sipilot-compro\\app\\layout.tsx"],
'head': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 70447)), "E:\\KERJAAN\\MaestroSupremeTech\\Projects\\website\\sipilot\\sipilot-compro\\app\\head.tsx"],
        }
      ]
      }.children;
    const pages = ["E:\\KERJAAN\\MaestroSupremeTech\\Projects\\website\\sipilot\\sipilot-compro\\app\\blog\\page.tsx"]

    
    
    
    

    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
  

/***/ }),

/***/ 102:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 60729));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 72079))

/***/ }),

/***/ 78543:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ */ const { createProxy  } = __webpack_require__(14353);
module.exports = createProxy("E:\\KERJAAN\\MaestroSupremeTech\\Projects\\website\\sipilot\\sipilot-compro\\app\\blog\\content.tsx");


/***/ }),

/***/ 30234:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Page)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(88499);
/* harmony import */ var _sipilot_components_Loader__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(21610);
/* harmony import */ var _sipilot_components_Loader__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_sipilot_components_Loader__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _sipilot_services_blog_blog_services__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9666);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(85468);
/* harmony import */ var _content__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(78543);
/* harmony import */ var _content__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_content__WEBPACK_IMPORTED_MODULE_4__);





async function Page() {
    const carouselData = await _sipilot_services_blog_blog_services__WEBPACK_IMPORTED_MODULE_2__/* .blogServices.getCarouselData */ .F.getCarouselData();
    const randomPost = await _sipilot_services_blog_blog_services__WEBPACK_IMPORTED_MODULE_2__/* .blogServices.random */ .F.random();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react__WEBPACK_IMPORTED_MODULE_3__.Suspense, {
        fallback: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_sipilot_components_Loader__WEBPACK_IMPORTED_MODULE_1___default()), {}),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_content__WEBPACK_IMPORTED_MODULE_4___default()), {
            carousel: carouselData,
            random: randomPost
        })
    });
}


/***/ }),

/***/ 60729:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ BlogContent)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/@mantine/core/cjs/index.js
var cjs = __webpack_require__(13162);
// EXTERNAL MODULE: ./node_modules/@mantine/carousel/cjs/index.js
var carousel_cjs = __webpack_require__(64188);
// EXTERNAL MODULE: ./node_modules/dayjs/dayjs.min.js
var dayjs_min = __webpack_require__(43598);
var dayjs_min_default = /*#__PURE__*/__webpack_require__.n(dayjs_min);
// EXTERNAL MODULE: ./node_modules/embla-carousel-autoplay/embla-carousel-autoplay.umd.js
var embla_carousel_autoplay_umd = __webpack_require__(17886);
var embla_carousel_autoplay_umd_default = /*#__PURE__*/__webpack_require__.n(embla_carousel_autoplay_umd);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
;// CONCATENATED MODULE: ./src/components/Sections/Blog/Recommendation.tsx








const useStyles = (0,cjs.createStyles)((_theme, _params, getRef)=>({
        controls: {
            ref: getRef("controls"),
            transition: "opacity 150ms ease",
            opacity: 0
        },
        root: {
            "&:hover": {
                [`& .${getRef("controls")}`]: {
                    opacity: 1
                }
            }
        }
    }));
function RecommendationBlog({ carousel  }) {
    const { classes  } = useStyles();
    const autoplay = (0,react_.useRef)(embla_carousel_autoplay_umd_default()({
        delay: 5000
    }));
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(cjs.Box, {
        pos: "relative",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(cjs.Container, {
                pt: "lg",
                children: /*#__PURE__*/ jsx_runtime_.jsx(carousel_cjs/* Carousel */.lr, {
                    loop: true,
                    slideGap: "md",
                    mx: "auto",
                    // height={200}
                    classNames: classes,
                    withIndicators: true,
                    plugins: [
                        autoplay.current
                    ],
                    onMouseEnter: autoplay.current.stop,
                    onMouseLeave: autoplay.current.reset,
                    children: carousel.map((v)=>/*#__PURE__*/ jsx_runtime_.jsx(carousel_cjs/* Carousel.Slide */.lr.Slide, {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(cjs.Anchor, {
                                pos: "relative",
                                style: {
                                    cursor: "pointer"
                                },
                                component: (link_default()),
                                href: `/blog/${v.slug}`,
                                color: "white",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(cjs.AspectRatio, {
                                        ratio: 1920 / 1080,
                                        mx: "auto",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: v.thumbnail[0],
                                            fill: true,
                                            alt: "Carousel-image",
                                            style: {
                                                objectFit: "cover"
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(cjs.Box, {
                                        pos: "absolute",
                                        bottom: 0,
                                        w: "100%",
                                        py: "xl",
                                        px: "xl",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(cjs.Text, {
                                                fw: "bold",
                                                children: dayjs_min_default()(v.published_at).format("DD/MM/YYYY")
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(cjs.Title, {
                                                children: v.title
                                            })
                                        ]
                                    })
                                ]
                            })
                        }, v.id))
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(cjs.Box, {
                pos: "absolute",
                h: "40%",
                w: "100%",
                left: 0,
                top: "60%",
                bg: "white",
                sx: {
                    zIndex: -1
                }
            })
        ]
    });
}
/* harmony default export */ const Recommendation = ((/* unused pure expression or super */ null && (RecommendationBlog)));

;// CONCATENATED MODULE: ./src/services/blog/blog.services.ts
const blogServices = {
    async getCarouselData () {
        const res = await fetch(`${"https://be.sipilot.id/api"}/post?perPage=5&published_only=true`, {
            cache: "no-store"
        });
        if (!res.ok) {
            // This will activate the closest `error.js` Error Boundary
            throw new Error("Failed to fetch data");
        }
        const data = await res.json();
        return data?.data?.items;
    },
    async categorized () {
        const res = await fetch(`${"https://be.sipilot.id/api"}/post?published_only=true`, {
            cache: "no-store"
        });
        if (!res.ok) {
            // This will activate the closest `error.js` Error Boundary
            throw new Error("Failed to fetch data");
        }
        const data = await res.json();
        return data?.data?.items;
    },
    async getAll (options) {
        const res = await fetch(`${"https://be.sipilot.id/api"}/post?` + new URLSearchParams({
            published_only: "true",
            ...options.params
        }), {
            cache: "no-store"
        });
        if (!res.ok) {
            // This will activate the closest `error.js` Error Boundary
            throw new Error("Failed to fetch data");
        }
        const data = await res.json();
        return data?.data?.items;
    },
    async getBySlug (slug) {
        const res = await fetch(`${"https://be.sipilot.id/api"}/post/${slug}`, {
            cache: "no-store"
        });
        if (!res.ok) {
            // This will activate the closest `error.js` Error Boundary
            throw new Error("Failed to fetch data");
        }
        const data = await res.json();
        return data?.data;
    },
    async random () {
        const res = await fetch(`${"https://be.sipilot.id/api"}/post/random`, {
            cache: "no-store"
        });
        if (!res.ok) {
            // This will activate the closest `error.js` Error Boundary
            throw new Error("Failed to fetch data");
        }
        const data = await res.json();
        return data?.data;
    },
    async getCategories () {
        const res = await fetch(`${"https://be.sipilot.id/api"}/categories`, {
            cache: "no-store"
        });
        if (!res.ok) {
            // This will activate the closest `error.js` Error Boundary
            throw new Error("Failed to fetch data");
        }
        const data = await res.json();
        return data?.data?.items;
    }
};

// EXTERNAL MODULE: ./node_modules/@tanstack/react-query/build/lib/useQuery.mjs + 6 modules
var useQuery = __webpack_require__(63542);
;// CONCATENATED MODULE: ./src/hooks/useCategories.ts


function useCategories() {
    return (0,useQuery/* useQuery */.a)([
        "categories"
    ], ()=>blogServices.getCategories());
}
/* harmony default export */ const hooks_useCategories = (useCategories);

;// CONCATENATED MODULE: ./src/hooks/useCategorizedBlog.ts


function useCategorizedBlog({ params ={}  }) {
    return (0,useQuery/* useQuery */.a)([
        "categorized-blog",
        params
    ], ()=>blogServices.getAll({
            params
        }));
}
/* harmony default export */ const hooks_useCategorizedBlog = (useCategorizedBlog);

;// CONCATENATED MODULE: ./src/components/Sections/Blog/Categorized.tsx









const TRANSITION_DURATION = 200;
function CategorizedBlog() {
    const [embla, setEmbla] = (0,react_.useState)(null);
    (0,carousel_cjs/* useAnimationOffsetEffect */.Db)(embla, TRANSITION_DURATION);
    const [selectedCategory, setSelectedCategory] = (0,react_.useState)("");
    const { data: categories  } = hooks_useCategories();
    const { data: blogs , isFetching  } = hooks_useCategorizedBlog({
        params: {
            perPage: 10,
            "filter.category.title": selectedCategory
        }
    });
    return /*#__PURE__*/ jsx_runtime_.jsx(cjs.Box, {
        bg: "white",
        children: /*#__PURE__*/ jsx_runtime_.jsx(cjs.Container, {
            py: "xl",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(cjs.Stack, {
                spacing: "xl",
                py: "xl",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(carousel_cjs/* Carousel */.lr, {
                        slideGap: "md",
                        dragFree: true,
                        draggable: true,
                        containScroll: "trimSnaps",
                        maw: "100%",
                        slideSize: "auto",
                        mx: "auto",
                        align: "start",
                        withControls: false,
                        getEmblaApi: setEmbla,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(carousel_cjs/* Carousel.Slide */.lr.Slide, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(cjs.Button, {
                                    onClick: ()=>{
                                        setSelectedCategory("");
                                    },
                                    variant: "outline",
                                    color: "black",
                                    ...!selectedCategory && {
                                        variant: "filled",
                                        color: "primary"
                                    },
                                    children: "All Categories"
                                })
                            }),
                            Array.isArray(categories) && categories.map((category, i)=>/*#__PURE__*/ jsx_runtime_.jsx(carousel_cjs/* Carousel.Slide */.lr.Slide, {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(cjs.Button, {
                                        onClick: ()=>{
                                            setSelectedCategory(category.slug);
                                        },
                                        variant: "outline",
                                        color: "black",
                                        ...category.slug === selectedCategory && {
                                            variant: "filled",
                                            color: "primary"
                                        },
                                        children: category.title
                                    })
                                }, i))
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(cjs.Box, {
                        mih: 500,
                        pos: "relative",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(cjs.LoadingOverlay, {
                                visible: isFetching,
                                overlayBlur: 10
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(cjs.Grid, {
                                gutter: "xl",
                                children: blogs?.map((v)=>/*#__PURE__*/ jsx_runtime_.jsx(cjs.Grid.Col, {
                                        sm: 6,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(BlogCard, {
                                            blog: v
                                        })
                                    }, v.id))
                            })
                        ]
                    })
                ]
            })
        })
    });
}
/* harmony default export */ const Categorized = ((/* unused pure expression or super */ null && (CategorizedBlog)));
const BlogCard = (props)=>{
    const { blog  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx(cjs.Card, {
        radius: "xl",
        bg: "black",
        sx: {
            cursor: "pointer",
            boxShadow: "0px 25px 25px -13px rgba(0, 0, 0, 0.25)"
        },
        component: (link_default()),
        href: `/blog/${blog.slug}`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(cjs.Stack, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(cjs.Paper, {
                    p: 0,
                    radius: "lg",
                    sx: {
                        overflow: "hidden",
                        boxShadow: "0px 25px 25px -13px #000000"
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx(cjs.AspectRatio, {
                        ratio: 4 / 3,
                        mx: "auto",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: blog.thumbnail[0],
                            // height={160}
                            alt: "thumbnail",
                            fill: true
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(cjs.Stack, {
                    spacing: "xs",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(cjs.Text, {
                            weight: "bold",
                            color: "white",
                            children: blog.title
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(cjs.Text, {
                            size: "sm",
                            color: "white",
                            children: dayjs_min_default()(blog.published_at).format("DD MMMM YYYY")
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(cjs.Text, {
                            lineClamp: 2,
                            color: "white",
                            dangerouslySetInnerHTML: {
                                __html: blog.body
                            }
                        })
                    ]
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./src/components/Sections/Blog/index.ts



;// CONCATENATED MODULE: ./app/blog/content.tsx






function BlogContent(props) {
    const { carousel , random  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(cjs.Box, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(RecommendationBlog, {
                carousel: carousel
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(CategorizedBlog, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(cjs.Container, {
                py: 32,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(cjs.Grid, {
                    gutter: 32,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(cjs.Grid.Col, {
                            span: 12,
                            sm: 5,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(cjs.Card, {
                                pos: "relative",
                                mih: 300,
                                h: "100%",
                                radius: "xl",
                                bg: "transparent",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: random.thumbnail[0],
                                    alt: "thumbnail",
                                    fill: true,
                                    style: {
                                        objectFit: "cover"
                                    }
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(cjs.Grid.Col, {
                            span: 12,
                            sm: 7,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(cjs.Stack, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(cjs.Title, {
                                        children: random.title
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(cjs.Title, {
                                        order: 3,
                                        children: dayjs_min_default()(random.published_at).format("DD MMMM YYYY")
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(cjs.Text, {
                                        lineClamp: 12,
                                        dangerouslySetInnerHTML: {
                                            __html: random.body
                                        }
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(cjs.Box, {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(cjs.Button, {
                                            component: (link_default()),
                                            href: `/post/${random.slug}`,
                                            children: "Pelajari Lebih lanjut"
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [826,188,598,713,849,333], () => (__webpack_exec__(68424)));
module.exports = __webpack_exports__;

})();