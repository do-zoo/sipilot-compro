(() => {
var exports = {};
exports.id = 547;
exports.ids = [547];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 53918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 64486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 99552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 78524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 47342:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/no-ssr-error.js");

/***/ }),

/***/ 64406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 46220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 10299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 35789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 34567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 15817:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(72315);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62333);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(62885);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(19505);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(90683);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(23269);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(85746);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8208);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7__);

    const tree = {
        children: [
        '',
        {
        children: [
        'packages',
        {
        children: ['', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 98333, 23)), "E:\\KERJAAN\\MaestroSupremeTech\\Projects\\website\\sipilot\\sipilot-compro\\app\\packages\\page.tsx"]}]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 70612)), "E:\\KERJAAN\\MaestroSupremeTech\\Projects\\website\\sipilot\\sipilot-compro\\app\\packages\\layout.tsx"],
'head': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 80971)), "E:\\KERJAAN\\MaestroSupremeTech\\Projects\\website\\sipilot\\sipilot-compro\\app\\packages\\head.tsx"],
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 48514)), "E:\\KERJAAN\\MaestroSupremeTech\\Projects\\website\\sipilot\\sipilot-compro\\app\\layout.tsx"],
'head': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 70447)), "E:\\KERJAAN\\MaestroSupremeTech\\Projects\\website\\sipilot\\sipilot-compro\\app\\head.tsx"],
        }
      ]
      }.children;
    const pages = ["E:\\KERJAAN\\MaestroSupremeTech\\Projects\\website\\sipilot\\sipilot-compro\\app\\packages\\page.tsx"]

    
    
    
    

    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
  

/***/ }),

/***/ 87311:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 48392))

/***/ }),

/***/ 80971:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Head)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(88499);

function Head() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                children: "Packages - Sipilot"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                content: "width=device-width, initial-scale=1",
                name: "viewport"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "description",
                content: "Generated by create next app"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                rel: "icon",
                href: "/favicon.ico"
            })
        ]
    });
}


/***/ }),

/***/ 70612:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ RootLayout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(88499);

function RootLayout({ children  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
            children: children
        })
    });
}


/***/ }),

/***/ 98333:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ */ const { createProxy  } = __webpack_require__(14353);
module.exports = createProxy("E:\\KERJAAN\\MaestroSupremeTech\\Projects\\website\\sipilot\\sipilot-compro\\app\\packages\\page.tsx");


/***/ }),

/***/ 57133:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/logo-with-text.845de658.png","height":73,"width":226,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAMAAACZFr56AAAAGFBMVEX4+Pn4+fn29/L39/f4+Pzw8BDx8SL4+flzftcWAAAACHRSTlMJoB0udVaLjsgd988AAAAJcEhZcwAACxMAAAsTAQCanBgAAAAfSURBVHicDcGHAQAACMKwAo7/P9aExiSYKUmronF4BwMOADPqKz9GAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":3});

/***/ }),

/***/ 48392:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Packages)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/@mantine/core/cjs/index.js
var cjs = __webpack_require__(13162);
// EXTERNAL MODULE: ./src/components/Sections/index.ts + 24 modules
var Sections = __webpack_require__(14706);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/assets/jpg/trusted-image.jpg
/* harmony default export */ const trusted_image = ({"src":"/_next/static/media/trusted-image.1e735068.jpg","height":458,"width":653,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAGAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAX/xAAdEAABBQADAQAAAAAAAAAAAAABAAIDBBEFEiFx/8QAFAEBAAAAAAAAAAAAAAAAAAAAAv/EABYRAQEBAAAAAAAAAAAAAAAAAAABEf/aAAwDAQACEQMRAD8Au0bnL1zG23ZjmD5eocAdJ0g7vmfEREoOv//Z","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./src/components/Sections/Faq.section.tsx




function FAQ() {
    return /*#__PURE__*/ jsx_runtime_.jsx(cjs.Box, {
        bg: "#3C3C3C",
        children: /*#__PURE__*/ jsx_runtime_.jsx(cjs.Container, {
            py: 60,
            size: "lg",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(cjs.Grid, {
                gutter: 32,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(cjs.Grid.Col, {
                        span: 12,
                        md: 7,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(cjs.Stack, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(cjs.Title, {
                                    children: "FAQ"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(cjs.Text, {
                                    children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit sed ab amet, labore saepe magni maiores dolorem consequuntur ut! Praesentium ratione nostrum, quibusdam perferendis maxime atque facere voluptatibus blanditiis possimus."
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(cjs.List, {
                                    spacing: "sm",
                                    withPadding: true,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(cjs.List.Item, {
                                            sx: (theme)=>({
                                                    "::marker": {
                                                        color: theme.white
                                                    },
                                                    marginLeft: "-16px"
                                                }),
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(cjs.Text, {
                                                color: "white",
                                                children: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eligendi culpa, dicta vitae inventore quam nam nulla consequatur deleniti unde in omnis sit blanditiis ab quaerat doloremque magnam modi libero? Ratione?"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(cjs.List.Item, {
                                            sx: (theme)=>({
                                                    "::marker": {
                                                        color: theme.white
                                                    },
                                                    marginLeft: "-16px"
                                                }),
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(cjs.Text, {
                                                color: "white",
                                                children: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eligendi culpa, dicta vitae inventore quam nam nulla consequatur deleniti unde in omnis sit blanditiis ab quaerat doloremque magnam modi libero? Ratione?"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(cjs.List.Item, {
                                            sx: (theme)=>({
                                                    "::marker": {
                                                        color: theme.white
                                                    },
                                                    marginLeft: "-16px"
                                                }),
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(cjs.Text, {
                                                color: "white",
                                                children: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eligendi culpa, dicta vitae inventore quam nam nulla consequatur deleniti unde in omnis sit blanditiis ab quaerat doloremque magnam modi libero? Ratione?"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(cjs.List.Item, {
                                            sx: (theme)=>({
                                                    "::marker": {
                                                        color: theme.white
                                                    },
                                                    marginLeft: "-16px"
                                                }),
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(cjs.Text, {
                                                color: "white",
                                                children: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eligendi culpa, dicta vitae inventore quam nam nulla consequatur deleniti unde in omnis sit blanditiis ab quaerat doloremque magnam modi libero? Ratione?"
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(cjs.Grid.Col, {
                        span: 12,
                        md: 5,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(cjs.Stack, {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(cjs.Card, {
                                pos: "relative",
                                pb: "100%",
                                radius: "xl",
                                bg: "transparent",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: trusted_image,
                                    alt: "trusted",
                                    fill: true,
                                    style: {
                                        objectFit: "cover"
                                    }
                                })
                            })
                        })
                    })
                ]
            })
        })
    });
}
/* harmony default export */ const Faq_section = (FAQ);

// EXTERNAL MODULE: ./src/assets/png/logo-with-text.png
var logo_with_text = __webpack_require__(57133);
// EXTERNAL MODULE: ./src/components/Sidebar/index.tsx
var Sidebar = __webpack_require__(11453);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./app/packages/navbar.tsx






const useStyles = (0,cjs.createStyles)((theme)=>({
        group: {
            justifyContent: "space-between",
            [theme.fn.largerThan("md")]: {
                justifyContent: "center"
            }
        }
    }));
function Navbar() {
    const { classes  } = useStyles();
    return /*#__PURE__*/ jsx_runtime_.jsx(cjs.Header, {
        height: 80,
        style: {
            position: "sticky",
            top: 0,
            background: "#1A1B1E",
            transition: "background ease-in 100ms"
        },
        withBorder: false,
        children: /*#__PURE__*/ jsx_runtime_.jsx(cjs.Container, {
            h: "100%",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(cjs.Group, {
                align: "center",
                h: "100%",
                className: classes.group,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(cjs.UnstyledButton, {
                        component: (link_default()),
                        href: "/",
                        scroll: true,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: logo_with_text/* default */.Z,
                            alt: "Logo",
                            height: 60
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Sidebar/* Sidebar */.Y, {})
                ]
            })
        })
    });
}
/* harmony default export */ const navbar = (Navbar);

;// CONCATENATED MODULE: ./app/packages/page.tsx





function Packages() {
    // const theme = useMantineTheme()
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(cjs.Box, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(navbar, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Sections/* PackagesAlt */.Jj, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Sections/* PackagesDetail */.K0, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Faq_section, {})
        ]
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [826,188,849,706], () => (__webpack_exec__(15817)));
module.exports = __webpack_exports__;

})();