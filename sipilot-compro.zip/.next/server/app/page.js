(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 53918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 64486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 99552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 78524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 47342:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/no-ssr-error.js");

/***/ }),

/***/ 64406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 46220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 10299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 35789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 34567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 19634:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(72315);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62333);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(62885);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(19505);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(90683);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(23269);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(85746);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8208);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7__);

    const tree = {
        children: [
        '',
        {
        children: ['', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7148)), "E:\\KERJAAN\\MaestroSupremeTech\\Projects\\website\\sipilot\\sipilot-compro\\app\\page.tsx"]}]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 48514)), "E:\\KERJAAN\\MaestroSupremeTech\\Projects\\website\\sipilot\\sipilot-compro\\app\\layout.tsx"],
'head': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 70447)), "E:\\KERJAAN\\MaestroSupremeTech\\Projects\\website\\sipilot\\sipilot-compro\\app\\head.tsx"],
        }
      ]
      }.children;
    const pages = ["E:\\KERJAAN\\MaestroSupremeTech\\Projects\\website\\sipilot\\sipilot-compro\\app\\page.tsx"]

    
    
    
    

    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
  

/***/ }),

/***/ 36920:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73478))

/***/ }),

/***/ 23778:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ */ const { createProxy  } = __webpack_require__(14353);
module.exports = createProxy("E:\\KERJAAN\\MaestroSupremeTech\\Projects\\website\\sipilot\\sipilot-compro\\app\\content.tsx");


/***/ }),

/***/ 7148:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Page)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(88499);
;// CONCATENATED MODULE: ./src/services/events/events.servicxe.ts
const eventServices = {
    async getAll () {
        const res = await fetch(`${"https://be.sipilot.id/api"}/event`, {
            next: {
                revalidate: 10
            }
        });
        if (!res.ok) {
            // This will activate the closest `error.js` Error Boundary
            throw new Error("Failed to fetch data");
        }
        const data = await res.json();
        return data?.data;
    },
    async upcoming () {
        const res = await fetch(`${"https://be.sipilot.id/api"}/event/upcoming`, {
            cache: "no-store"
        });
        if (!res.ok) {
            // This will activate the closest `error.js` Error Boundary
            throw new Error("Failed to fetch data");
        }
        const data = await res.json();
        return data?.data;
    }
};

;// CONCATENATED MODULE: ./src/services/pages/home.service.ts
const homeServices = {
    async getHomeData () {
        const res = await fetch(`${"https://be.sipilot.id/api"}/maincontent`, {
            cache: "no-store"
        });
        if (!res.ok) {
            // This will activate the closest `error.js` Error Boundary
            throw new Error("Failed to fetch data");
        }
        const data = await res.json();
        return data?.data;
    }
};

// EXTERNAL MODULE: ./app/content.tsx
var content = __webpack_require__(23778);
var content_default = /*#__PURE__*/__webpack_require__.n(content);
;// CONCATENATED MODULE: ./app/page.tsx




async function Page() {
    const data = await homeServices.getHomeData();
    const events = await eventServices.getAll();
    const upcomingEvent = await eventServices.upcoming();
    return /*#__PURE__*/ jsx_runtime.jsx("div", {
        children: /*#__PURE__*/ jsx_runtime.jsx((content_default()), {
            data: data,
            events: events,
            upcomingEvent: upcomingEvent
        })
    });
}


/***/ }),

/***/ 73478:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ content)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/@mantine/core/cjs/index.js
var cjs = __webpack_require__(13162);
// EXTERNAL MODULE: ./src/components/Sections/index.ts + 24 modules
var Sections = __webpack_require__(14706);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/@mantine/hooks/cjs/index.js
var hooks_cjs = __webpack_require__(76568);
// EXTERNAL MODULE: ./src/components/Sidebar/index.tsx
var Sidebar = __webpack_require__(11453);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./src/assets/png/logo-text-white.png
var logo_text_white = __webpack_require__(23291);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./app/navbar.tsx








const useStyles = (0,cjs.createStyles)((theme)=>({
        hiddenMobile: {
            [theme.fn.smallerThan("md")]: {
                display: "none"
            }
        },
        group: {
            justifyContent: "space-between",
            [theme.fn.largerThan("md")]: {
                justifyContent: "space-between"
            }
        },
        link: {
            display: "flex",
            alignItems: "center",
            height: "100%",
            paddingLeft: theme.spacing.md,
            paddingRight: theme.spacing.md,
            textDecoration: "none",
            color: theme.white,
            fontWeight: 500,
            fontSize: theme.fontSizes.sm,
            [theme.fn.smallerThan("sm")]: {
                height: 42,
                display: "flex",
                alignItems: "center",
                width: "100%"
            },
            ...theme.fn.hover({
                backgroundColor: theme.colors.dark[6]
            })
        }
    }));
function Navbar() {
    const { classes  } = useStyles();
    const headerContainer = (0,react_.useRef)(null);
    const { ref , entry  } = (0,hooks_cjs.useIntersection)({
        root: headerContainer.current,
        threshold: 1,
        rootMargin: "60px"
    });
    return /*#__PURE__*/ jsx_runtime_.jsx(cjs.Box, {
        ref: ref,
        children: /*#__PURE__*/ jsx_runtime_.jsx(cjs.Header, {
            height: 80,
            style: {
                position: "fixed",
                top: 0,
                background: !entry?.isIntersecting ? "#1A1B1E" : "transparent",
                transition: "background ease-in 100ms"
            },
            withBorder: false,
            children: /*#__PURE__*/ jsx_runtime_.jsx(cjs.Container, {
                h: "100%",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(cjs.Group, {
                    position: "apart",
                    align: "center",
                    h: "100%",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(cjs.Box, {
                            component: (link_default()),
                            href: "/",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: logo_text_white/* default */.Z,
                                alt: "Logo"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(cjs.Group, {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(cjs.Group, {
                                className: classes.hiddenMobile,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(cjs.Anchor, {
                                        href: "/",
                                        component: (link_default()),
                                        type: "button",
                                        className: classes.link,
                                        scroll: true,
                                        children: "Home"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(cjs.Anchor, {
                                        href: "/packages",
                                        component: (link_default()),
                                        type: "button",
                                        className: classes.link,
                                        scroll: true,
                                        children: "Pricing"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(cjs.Anchor, {
                                        href: "/blog",
                                        component: (link_default()),
                                        type: "button",
                                        className: classes.link,
                                        scroll: true,
                                        children: "Blog"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(cjs.Anchor, {
                                        href: "#footer",
                                        component: "a",
                                        type: "button",
                                        className: classes.link,
                                        children: "Become a member"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(cjs.Button, {
                            variant: "outline",
                            size: "lg",
                            component: "a",
                            href: "#footer",
                            className: classes.hiddenMobile,
                            children: "Contact us"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Sidebar/* Sidebar */.Y, {})
                    ]
                })
            })
        })
    });
}
/* harmony default export */ const navbar = (Navbar);

;// CONCATENATED MODULE: ./app/content.tsx





function Content(props) {
    const { data , events , upcomingEvent  } = props;
    const heroData = (0,react_.useMemo)(()=>{
        return data?.["1"];
    }, [
        data
    ]);
    const trustedData1 = (0,react_.useMemo)(()=>{
        return data?.["2"];
    }, [
        data
    ]);
    const trustedData2 = (0,react_.useMemo)(()=>{
        return data?.["3"];
    }, [
        data
    ]);
    const clientReview = (0,react_.useMemo)(()=>{
        return data?.["5"];
    }, [
        data
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(navbar, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Sections/* Hero */.VM, {
                data: heroData
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(cjs.Container, {
                id: "advantage",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Sections/* AdvantageSection */.FC, {
                        data: trustedData1
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Sections/* AdvantageSection */.FC, {
                        data: trustedData2,
                        reverse: true
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Sections/* EventCountdown */.e2, {
                event: upcomingEvent
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Sections/* ProjectReport */.vw, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Sections/* ClientReceive */.nl, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Sections/* NewEvents */.fq, {
                events: events
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Sections/* Packages */.bs, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Sections/* Testimony */.U4, {
                data: clientReview
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Sections/* Clients */.eT, {})
        ]
    });
}
/* harmony default export */ const content = (Content);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [826,188,849,706], () => (__webpack_exec__(19634)));
module.exports = __webpack_exports__;

})();