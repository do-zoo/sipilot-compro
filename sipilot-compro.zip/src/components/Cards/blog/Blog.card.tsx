import React from 'react'

export function BlogCard() {
  return <div>BlogCard</div>
}

export default BlogCard
