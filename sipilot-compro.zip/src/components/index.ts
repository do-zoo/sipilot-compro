export const components = 'anjing'
